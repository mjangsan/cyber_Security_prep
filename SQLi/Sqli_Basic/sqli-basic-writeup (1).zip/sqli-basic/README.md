# SQL Injection — Basic Labs (Filter Bypass & Login Bypass)

> Personal lab notes, cleaned up for a GitHub write-up. Testing was done against intentionally vulnerable training labs, not a live/production system.

## Lab 1: Category Filter is Vulnerable to SQL Injection

**Goal:** confirm the category filter is injectable, then use that to retrieve unreleased products.

### Steps

1. Injected `'--` into the category parameter. This returned one extra object in the response compared to the normal filter — confirming the application reacts to SQL injection.

   ![Lab 1 - initial injection confirms extra object returned](images/basic/lab1-step1.png)
   ![Lab 1 - response showing the unreleased product](images/basic/lab1-step1b.png)

2. Tried the payload `' or1=1--` (no space between `or` and `1`). This caused an internal server error.

   ![Lab 1 - no space causes 500 error](images/basic/lab1-step2.png)

3. Added a space between the logic condition: `' or 1=1--`. This worked — the filter returned all products, including the unreleased ones.

   ![Lab 1 - with a space, the payload succeeds](images/basic/lab1-step3.png)

**Takeaway:** the parser needs whitespace around keywords/operators; a missing space broke the query syntax rather than the logic.

## Lab 2: SQL Injection Allowing Login Bypass

**Goal:** access the admin page without valid credentials.

### Steps

1. The `/login` page has two fields: username and password. With no valid credentials, I tried accessing `/admin` directly — got a 404.
2. Confirmed the login form was injectable by sending `'--` in the username field, which returned a `200 OK` from the backend (rather than an auth failure).

   ![Lab 2 - confirming sqli with a 200 OK response](images/basic/lab2-step1.png)

3. Tried `' or '1'='1--`. The single quote got escaped by the application, so this payload failed.

   ![Lab 2 - escaped quote causes the payload to fail](images/basic/lab2-step2.png)

4. Tried `' or 1=1--` (numeric comparison, no quotes to escape). This succeeded and logged in directly as the administrator.

   ![Lab 2 - numeric payload succeeds, redirected to admin](images/basic/lab2-step3.png)

5. Confirmed: landed on a working admin page.

   ![Lab 2 - successful admin page](images/basic/lab2-step4.png)

**Takeaway:** the app sanitized/escaped quote characters but the injected condition didn't need a quoted string comparison — using a bare numeric `1=1` sidestepped the escaping entirely.

## Lessons

- A small syntax detail (missing whitespace, an escaped quote) can make or break a payload — when one form fails, try an equivalent that avoids the character being filtered/escaped.
- A `200 OK` instead of an expected error page is itself a useful signal that the input reached the query layer.

## Remediation

- Use parameterized queries / prepared statements instead of concatenating user input into SQL.
- Don't rely on quote-escaping alone for sanitization — it can be bypassed with payloads that don't need quotes (e.g. `OR 1=1`).
- Apply least-privilege DB accounts and proper authN/authZ checks server-side, independent of the login query's result.
